import { Full } from './layouts/Full'

export const Tours = () => {
    return (
        <Full>
            <div>tours</div>
        </Full>
    )
}

import { Full } from './layouts/Full'

export const HelpCenter = () => {
    return (
        <Full>
            <div>help center</div>
        </Full>
    )
}

<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

_deprecated_file( 'ReduxCore/inc/fields/typography/typography.php', '4.3', 'redux-core/inc/fields/class-redux-typography.php', 'This file has been discontinued and is no longer used in Redux 4.  Please remove any references to it as it will be removed in future versions of Redux.' );

